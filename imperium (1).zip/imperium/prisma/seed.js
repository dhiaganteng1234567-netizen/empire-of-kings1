import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const countries = [
  { code: 'VAL', name: 'Valdoria', capital: 'Port Halden', flagColors: '#1f3a8a,#f4f4f4,#b89a5e' },
  { code: 'KAR', name: 'Karthos', capital: 'Ironspire', flagColors: '#7a1f2b,#1d2a47,#7a1f2b' },
  { code: 'SOR', name: 'Soravia', capital: 'Lindenmark', flagColors: '#2f6b4f,#f4f4f4,#2f6b4f' },
  { code: 'MER', name: 'Meridia', capital: 'Solhaven', flagColors: '#c58b2a,#1f3a8a,#c58b2a' },
];

for (const c of countries) {
  await prisma.country.upsert({ where: { code: c.code }, update: {}, create: c });
}
console.log(`Seeded ${countries.length} countries.`);
await prisma.$disconnect();
