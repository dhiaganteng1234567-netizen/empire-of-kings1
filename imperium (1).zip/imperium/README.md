# IMPERIUM — Stage 1 (Foundation)

Node 20+, PostgreSQL 14+.

## Run
```bash
docker run -d --name imperium-db -e POSTGRES_USER=imperium -e POSTGRES_PASSWORD=change-me \
  -e POSTGRES_DB=imperium -p 5432:5432 postgres:16     # or use any Postgres
npm install
cp .env.example .env          # set DATABASE_URL and SESSION_SECRET
npx prisma migrate dev --name init   # creates tables + the first migration
npm run seed                  # 4 countries
npm run dev                   # http://localhost:3000 (frontend and API on one server)
```

## Test Stage 1 by hand
1. Register account A in one browser, account B in a private window.
2. Sign in/out; confirm the session survives a page refresh and ends on logout.
3. A: set profile to Private; B: search A under Players and confirm bio/country are hidden.
4. Check tables `User`, `Profile`, `ActivityLog`, `AuditLog`, `user_sessions` in Postgres; `passwordHash` must start with `$argon2id$`.
5. In a terminal: `curl -X POST localhost:3000/api/auth/login -d '{}' -H 'Content-Type: application/json'` must return 403 (missing client header).

## Not in Stage 1 yet
Forgot/reset password, avatar upload, achievements, notifications page, settings beyond profile, real-time presence (Stage 2).
