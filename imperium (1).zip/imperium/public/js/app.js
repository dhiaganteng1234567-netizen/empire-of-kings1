import { api } from './api.js';
import { toast, esc } from './ui.js';
import { loginPage, registerPage } from './pages/auth.js';
import { dashboardPage } from './pages/dashboard.js';
import { playersPage, playerPage, myProfilePage } from './pages/players.js';

const root = document.getElementById('app');
let user = null;

const routes = [
  { re: /^\/login$/, fn: loginPage, guest: true },
  { re: /^\/register$/, fn: registerPage, guest: true },
  { re: /^\/$/, fn: dashboardPage },
  { re: /^\/players$/, fn: playersPage },
  { re: /^\/player\/([^/]+)$/, fn: playerPage },
  { re: /^\/me$/, fn: myProfilePage },
];

const ctx = {
  root,
  get user() { return user; },
  setUser(u) { user = u; },
  params: [],
};

async function render() {
  const path = location.hash.slice(1) || '/';
  const match = routes.map((r) => ({ r, m: path.match(r.re) })).find((x) => x.m);
  if (!match) { location.hash = user ? '#/' : '#/login'; return; }
  if (!user && !match.r.guest) { location.hash = '#/login'; return; }
  if (user && match.r.guest) { location.hash = '#/'; return; }
  ctx.params = match.m.slice(1).map(decodeURIComponent);
  try {
    await match.r.fn(ctx);
    window.scrollTo(0, 0);
  } catch (err) {
    if (err.status === 401) { user = null; location.hash = '#/login'; return; }
    root.innerHTML = `<div class="auth"><div class="card"><h2>Something went wrong</h2><p class="mute">${esc(err.message)}</p><p><a href="#/">Back to dashboard</a></p></div></div>`;
  }
}

document.addEventListener('click', async (e) => {
  if (e.target.closest('[data-action=logout]')) {
    try { await api('/auth/logout', { method: 'POST' }); } catch { /* session may already be gone */ }
    user = null;
    location.hash = '#/login';
  }
});

window.addEventListener('hashchange', render);
try { user = (await api('/auth/me')).user; } catch (e) { toast(e.message); }
render();
