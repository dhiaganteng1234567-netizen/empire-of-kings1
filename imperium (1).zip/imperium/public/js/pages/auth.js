import { api } from '../api.js';
import { esc, flag, fieldErr } from '../ui.js';

const frame = (inner) => `<div class="auth"><div class="auth-box">
  <div class="wordmark">IMPERIUM</div><p class="mute">A persistent world run by its players.</p>${inner}</div></div>`;

function bindForm(root, ctx, endpoint) {
  const form = root.querySelector('form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type=submit]');
    btn.disabled = true;
    form.querySelectorAll('.err').forEach((n) => n.remove());
    try {
      const body = Object.fromEntries(new FormData(form));
      const { user } = await api(endpoint, { method: 'POST', body });
      ctx.setUser(user);
      location.hash = '#/';
    } catch (err) {
      for (const [name, msgs] of Object.entries(err.fields || {})) {
        form.elements[name]?.insertAdjacentHTML('afterend', fieldErr({ [name]: msgs }, name));
      }
      if (!Object.keys(err.fields || {}).length) form.insertAdjacentHTML('beforeend', `<div class="err" role="alert">${esc(err.message)}</div>`);
      btn.disabled = false;
    }
  });
}

export async function loginPage(ctx) {
  ctx.root.innerHTML = frame(`<div class="card"><h2>Sign in</h2>
    <form novalidate>
      <label for="identifier">Username or email</label><input id="identifier" name="identifier" autocomplete="username" required>
      <label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required>
      <button class="btn block" type="submit">Sign in</button>
    </form></div>
    <p class="mute" style="margin-top:1rem">New here? <a href="#/register">Create an account</a></p>`);
  bindForm(ctx.root, ctx, '/auth/login');
}

export async function registerPage(ctx) {
  const { countries } = await api('/world/countries');
  const opts = countries.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  ctx.root.innerHTML = frame(`<div class="card"><h2>Create your account</h2>
    <form novalidate>
      <label for="username">Username</label><input id="username" name="username" autocomplete="username" required>
      <label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" required>
      <label for="password">Password (10+ characters)</label><input id="password" name="password" type="password" autocomplete="new-password" required>
      <label for="countryId">Home country</label>
      <select id="countryId" name="countryId" required><option value="">Choose a country</option>${opts}</select>
      <div id="flagPreview" style="margin-top:.5rem"></div>
      <button class="btn block" type="submit">Create account</button>
    </form></div>
    <p class="mute" style="margin-top:1rem">Already registered? <a href="#/login">Sign in</a></p>`);
  const sel = ctx.root.querySelector('#countryId');
  sel.addEventListener('change', () => {
    const c = countries.find((x) => x.id === sel.value);
    ctx.root.querySelector('#flagPreview').innerHTML = c ? `${flag(c.flagColors)} <span class="mute">Capital: ${esc(c.capital)}</span>` : '';
  });
  bindForm(ctx.root, ctx, '/auth/register');
}
