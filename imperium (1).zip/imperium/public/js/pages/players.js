import { api } from '../api.js';
import { esc, flag, shell, toast, fieldErr, timeAgo } from '../ui.js';

const row = (p) => `<a class="row" href="#/player/${encodeURIComponent(p.username)}">
  <span class="dot ${p.online ? 'on' : ''}" title="${p.online ? 'Online' : 'Offline'}"></span>
  ${p.country ? flag(p.country.flagColors) : ''}
  <div class="grow">${esc(p.displayName)} <span class="mute">@${esc(p.username)}</span></div>
  <span class="mute">${p.country ? esc(p.country.name) : 'Private'}</span></a>`;

export async function playersPage(ctx) {
  ctx.root.innerHTML = shell(ctx.user, '/players', 'Players', `
    <div class="card"><label for="q" style="margin-top:0">Search by username</label>
    <input id="q" type="search" autocomplete="off" maxlength="20"><div id="results" style="margin-top:.75rem"></div></div>`);
  const input = ctx.root.querySelector('#q');
  const out = ctx.root.querySelector('#results');
  let timer;
  const run = async () => {
    const { players } = await api('/players?q=' + encodeURIComponent(input.value));
    out.innerHTML = players.map(row).join('') || '<p class="mute">No players match that name.</p>';
  };
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => run().catch((e) => toast(e.message)), 250); });
  await run();
}

const view = (p) => p.private
  ? `<p class="mute">This player keeps their profile private.</p>`
  : `<div class="row">${flag(p.country.flagColors)}<div class="grow"><strong>${esc(p.country.name)}</strong> <span class="mute">citizen</span></div></div>
     ${p.bio ? `<p style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(p.bio)}</p>` : '<p class="mute">No bio yet.</p>'}
     <p class="mute">Joined ${new Date(p.joinedAt).toLocaleDateString()} · ${p.online ? 'Online now' : 'Last seen ' + timeAgo(p.lastSeenAt)}</p>`;

export async function playerPage(ctx) {
  const { player, isSelf } = await api('/players/' + encodeURIComponent(ctx.params[0]));
  ctx.root.innerHTML = shell(ctx.user, isSelf ? '/me' : '/players', player.displayName,
    `<div class="card"><p class="mute">@${esc(player.username)}</p>${view(player)}</div>`);
}

export async function myProfilePage(ctx) {
  const u = ctx.user;
  const { player } = await api('/players/' + encodeURIComponent(u.username));
  ctx.root.innerHTML = shell(u, '/me', 'My profile', `
    <div class="stack">
      <div class="card"><h2>How others see you</h2><p class="mute">@${esc(u.username)}</p>${view(player)}</div>
      <div class="card"><h2>Edit profile</h2>
        <form novalidate>
          <label for="displayName">Display name</label><input id="displayName" name="displayName" maxlength="30" value="${esc(u.displayName)}">
          <label for="bio">Bio</label><textarea id="bio" name="bio" maxlength="280">${esc(u.bio)}</textarea>
          <label for="privacy">Profile visibility</label>
          <select id="privacy" name="privacy">
            <option value="PUBLIC" ${u.privacy === 'PUBLIC' ? 'selected' : ''}>Public to signed-in players</option>
            <option value="PRIVATE" ${u.privacy === 'PRIVATE' ? 'selected' : ''}>Private</option></select>
          <button class="btn block" type="submit">Save changes</button>
        </form></div></div>`);
  const form = ctx.root.querySelector('form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    form.querySelectorAll('.err').forEach((n) => n.remove());
    try {
      const { user } = await api('/me/profile', { method: 'PATCH', body: Object.fromEntries(new FormData(form)) });
      ctx.setUser(user);
      toast('Saved');
      await myProfilePage(ctx);
    } catch (err) {
      for (const [n, m] of Object.entries(err.fields || {})) form.elements[n]?.insertAdjacentHTML('afterend', fieldErr({ [n]: m }, n));
      if (!Object.keys(err.fields || {}).length) toast(err.message);
    }
  });
}
