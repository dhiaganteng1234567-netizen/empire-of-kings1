import { api } from '../api.js';
import { esc, flag, shell, timeAgo } from '../ui.js';

export async function dashboardPage(ctx) {
  const u = ctx.user;
  const [world, act] = await Promise.all([api('/world/summary'), api('/me/activity')]);
  const countries = world.countries.map((c) => `<div class="row">${flag(c.flagColors)}
      <div class="grow">${esc(c.name)}<div class="mute">Capital: ${esc(c.capital)}</div></div>
      <span class="badge">${c.citizens} citizen${c.citizens === 1 ? '' : 's'}</span></div>`).join('');
  const items = act.items.map((a) => `<div class="row"><div class="grow">${esc(a.message)}</div><span class="mute">${timeAgo(a.createdAt)}</span></div>`).join('');

  ctx.root.innerHTML = shell(u, '/', `Welcome, ${u.displayName}`, `
    <div class="grid">
      <div class="card"><div class="mute">Your country</div>
        <div class="row">${flag(u.country.flagColors)}<div class="grow"><h2 style="margin:0">${esc(u.country.name)}</h2><div class="mute">Capital: ${esc(u.country.capital)}</div></div></div></div>
      <div class="card"><div class="mute">Players online now</div><div class="stat">${world.onlinePlayers}</div></div>
      <div class="card"><div class="mute">Registered players</div><div class="stat">${world.totalPlayers}</div></div>
    </div>
    <div class="grid" style="margin-top:1rem">
      <div class="card"><h2>Countries</h2>${countries}</div>
      <div class="card"><h2>Your recent activity</h2>${items || '<p class="mute">Nothing yet.</p>'}</div>
    </div>
    <div class="card" style="margin-top:1rem"><h2>Not built yet</h2>
      <p class="mute">Economy, companies, politics, diplomacy, military and chat arrive in later stages. They are not part of this build.</p></div>`);
}
