// Escape everything that comes from the server before putting it in HTML (XSS defence).
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function flag(colors) {
  const parts = String(colors || '#2a3858').split(',').filter((c) => /^#[0-9a-fA-F]{3,8}$/.test(c));
  const n = parts.length || 1;
  const stops = (parts.length ? parts : ['#2a3858']).map((c, i) => `${c} ${(i * 100) / n}% ${((i + 1) * 100) / n}%`).join(',');
  return `<span class="flag" style="background:linear-gradient(90deg,${stops})" aria-hidden="true"></span>`;
}

export function timeAgo(iso) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
}

let toastTimer;
export function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

export const fieldErr = (fields, name) => (fields?.[name]?.[0] ? `<div class="err">${esc(fields[name][0])}</div>` : '');

const NAV = [['/', 'Dashboard'], ['/players', 'Players'], ['/me', 'My profile']];

export function shell(user, active, title, body) {
  const nav = NAV.map(([p, l]) => `<a href="#${p}" ${p === active ? 'aria-current="page"' : ''}>${l}</a>`).join('');
  return `<div class="shell">
    <aside class="side"><div class="wordmark">IMPERIUM</div><nav class="nav" aria-label="Main">${nav}</nav></aside>
    <main class="main">
      <div class="top"><h1>${esc(title)}</h1>
        <div class="top-right"><span class="mute">${esc(user.username)}</span>
        <button class="btn ghost" data-action="logout">Log out</button></div></div>
      ${body}
    </main></div>`;
}
