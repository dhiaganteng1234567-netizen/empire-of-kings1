import { Router } from 'express';
import { prisma } from '../db.js';
import { config } from '../config.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// Public: the register form needs it.
router.get('/countries', async (_req, res, next) => {
  try {
    res.json({ countries: await prisma.country.findMany({ orderBy: { name: 'asc' } }) });
  } catch (e) { next(e); }
});

router.get('/summary', requireAuth, async (_req, res, next) => {
  try {
    const since = new Date(Date.now() - config.onlineWindowMs);
    const [totalPlayers, onlinePlayers, countries] = await Promise.all([
      prisma.user.count({ where: { status: 'ACTIVE' } }),
      prisma.user.count({ where: { status: 'ACTIVE', lastSeenAt: { gte: since } } }),
      prisma.country.findMany({ orderBy: { name: 'asc' }, include: { _count: { select: { profiles: true } } } }),
    ]);
    res.json({
      totalPlayers, onlinePlayers,
      countries: countries.map((c) => ({
        id: c.id, code: c.code, name: c.name, capital: c.capital,
        flagColors: c.flagColors, citizens: c._count.profiles,
      })),
    });
  } catch (e) { next(e); }
});

export default router;
