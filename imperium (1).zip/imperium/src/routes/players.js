import { Router } from 'express';
import { prisma } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { USER_INCLUDE, publicPlayer } from '../serialize.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q ?? '').trim().toLowerCase().slice(0, 20);
    const users = await prisma.user.findMany({
      where: { status: 'ACTIVE', ...(q && { usernameKey: { contains: q } }) },
      include: USER_INCLUDE, orderBy: { lastSeenAt: 'desc' }, take: 20,
    });
    res.json({ players: users.map(publicPlayer) });
  } catch (e) { next(e); }
});

router.get('/:username', async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { usernameKey: req.params.username.toLowerCase() }, include: USER_INCLUDE,
    });
    if (!user || user.status !== 'ACTIVE') return res.status(404).json({ error: 'Player not found.' });
    res.json({ player: publicPlayer(user), isSelf: user.id === req.user.id });
  } catch (e) { next(e); }
});

export default router;
