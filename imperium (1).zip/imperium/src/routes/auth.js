import { Router } from 'express';
import argon2 from 'argon2';
import rateLimit from 'express-rate-limit';
import { prisma } from '../db.js';
import { registerSchema, loginSchema } from '../validators.js';
import { audit } from '../audit.js';
import { loadUser } from '../middleware/auth.js';
import { USER_INCLUDE, selfUser } from '../serialize.js';

const router = Router();
const ARGON = { type: argon2.argon2id };
// Verified against when the account doesn't exist, so response time doesn't reveal it.
const DUMMY_HASH = await argon2.hash('imperium-dummy-password', ARGON);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in a few minutes.' },
});

// New session id on every sign-in prevents session fixation.
const startSession = (req, userId) =>
  new Promise((resolve, reject) =>
    req.session.regenerate((err) => {
      if (err) return reject(err);
      req.session.userId = userId;
      req.session.save((e) => (e ? reject(e) : resolve()));
    }));

router.get('/me', async (req, res, next) => {
  try {
    const user = await loadUser(req);
    res.json({ user: user ? selfUser(user) : null });
  } catch (e) { next(e); }
});

router.post('/register', limiter, async (req, res, next) => {
  try {
    const d = registerSchema.parse(req.body);
    const country = await prisma.country.findUnique({ where: { id: d.countryId } });
    if (!country) return res.status(400).json({ error: 'Choose a valid country.', fields: { countryId: ['Choose a valid country.'] } });

    const passwordHash = await argon2.hash(d.password, ARGON);
    let user;
    try {
      user = await prisma.user.create({
        data: {
          username: d.username, usernameKey: d.username.toLowerCase(), email: d.email, passwordHash,
          profile: { create: { displayName: d.username, countryId: country.id } },
          activities: { create: { type: 'JOINED', message: `Became a citizen of ${country.name}` } },
        },
        include: USER_INCLUDE,
      });
    } catch (e) {
      if (e.code === 'P2002') return res.status(409).json({ error: 'That username or email is already registered.' });
      throw e;
    }
    await startSession(req, user.id);
    audit(req, 'REGISTER', user.id);
    res.status(201).json({ user: selfUser(user) });
  } catch (e) { next(e); }
});

router.post('/login', limiter, async (req, res, next) => {
  try {
    const d = loginSchema.parse(req.body);
    const id = d.identifier.toLowerCase();
    const user = await prisma.user.findFirst({
      where: { OR: [{ usernameKey: id }, { email: id }] }, include: USER_INCLUDE,
    });
    const ok = await argon2.verify(user?.passwordHash ?? DUMMY_HASH, d.password);
    if (!user || !ok) {
      audit(req, 'LOGIN_FAILED', user?.id ?? null);
      return res.status(401).json({ error: 'Wrong username/email or password.' });
    }
    if (user.status !== 'ACTIVE') return res.status(403).json({ error: 'This account is not active.' });

    await prisma.user.update({ where: { id: user.id }, data: { lastSeenAt: new Date() } });
    await prisma.activityLog.create({ data: { userId: user.id, type: 'LOGIN', message: 'Signed in' } });
    await startSession(req, user.id);
    audit(req, 'LOGIN', user.id);
    res.json({ user: selfUser(user) });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res) => {
  const uid = req.session?.userId ?? null;
  req.session.destroy(() => {
    res.clearCookie('imperium.sid');
    if (uid) audit(req, 'LOGOUT', uid);
    res.json({ ok: true });
  });
});

export default router;
