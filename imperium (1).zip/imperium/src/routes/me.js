import { Router } from 'express';
import { prisma } from '../db.js';
import { profileSchema } from '../validators.js';
import { requireAuth } from '../middleware/auth.js';
import { USER_INCLUDE, selfUser } from '../serialize.js';

const router = Router();
router.use(requireAuth);

router.patch('/profile', async (req, res, next) => {
  try {
    const d = profileSchema.parse(req.body);
    await prisma.profile.update({ where: { userId: req.user.id }, data: d });
    await prisma.activityLog.create({ data: { userId: req.user.id, type: 'PROFILE', message: 'Updated profile' } });
    const user = await prisma.user.findUnique({ where: { id: req.user.id }, include: USER_INCLUDE });
    res.json({ user: selfUser(user) });
  } catch (e) { next(e); }
});

router.get('/activity', async (req, res, next) => {
  try {
    const items = await prisma.activityLog.findMany({
      where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 10,
      select: { id: true, type: true, message: true, createdAt: true },
    });
    res.json({ items });
  } catch (e) { next(e); }
});

export default router;
