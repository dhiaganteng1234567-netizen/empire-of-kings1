import http from 'node:http';
import { config } from './config.js';
import { createApp } from './app.js';
import { prisma } from './db.js';

await prisma.$connect(); // fail fast if the database is unreachable

const server = http.createServer(createApp());
// Stage 2: attach Socket.IO to `server` here, sharing sessionMiddleware.
server.listen(config.port, () => console.log(`IMPERIUM listening on http://localhost:${config.port}`));

const shutdown = async () => {
  server.close();
  await prisma.$disconnect();
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
