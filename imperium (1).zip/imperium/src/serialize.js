import { config } from './config.js';

export const USER_INCLUDE = { profile: { include: { country: true } } };

const country = (c) => c && { id: c.id, code: c.code, name: c.name, capital: c.capital, flagColors: c.flagColors };
export const isOnline = (u) => Date.now() - u.lastSeenAt.getTime() < config.onlineWindowMs;

// Data the signed-in user may see about themselves.
export const selfUser = (u) => ({
  id: u.id, username: u.username, role: u.role, createdAt: u.createdAt,
  displayName: u.profile.displayName, bio: u.profile.bio, privacy: u.profile.privacy,
  country: country(u.profile.country),
});

// Data other players may see, respecting privacy.
export const publicPlayer = (u) => {
  const base = { username: u.username, online: isOnline(u), private: u.profile.privacy === 'PRIVATE' };
  if (base.private) return { ...base, displayName: u.username };
  return {
    ...base, displayName: u.profile.displayName, bio: u.profile.bio,
    country: country(u.profile.country), joinedAt: u.createdAt, lastSeenAt: u.lastSeenAt,
  };
};
