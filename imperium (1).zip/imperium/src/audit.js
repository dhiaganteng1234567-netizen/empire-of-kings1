import { prisma } from './db.js';

export function audit(req, action, actorId = null, meta = undefined) {
  return prisma.auditLog
    .create({ data: { action, actorId, ip: req.ip, meta } })
    .catch((e) => console.error('audit failed', e.message));
}
