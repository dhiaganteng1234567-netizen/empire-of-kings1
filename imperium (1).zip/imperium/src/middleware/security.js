// CSRF defence for a cookie-session API: state-changing requests must carry a
// custom header (forces a CORS preflight for cross-site pages) and, if the
// browser sends an Origin, it must match this host. Cookies are SameSite=Lax too.
export function sameOriginGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-imperium-client') !== '1') return res.status(403).json({ error: 'Invalid request.' });
  const origin = req.get('origin');
  if (origin) {
    try {
      if (new URL(origin).host !== req.get('host')) throw new Error('mismatch');
    } catch {
      return res.status(403).json({ error: 'Invalid request origin.' });
    }
  }
  next();
}
