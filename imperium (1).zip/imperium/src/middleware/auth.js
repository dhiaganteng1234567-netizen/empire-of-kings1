import { prisma } from '../db.js';
import { USER_INCLUDE } from '../serialize.js';

export async function loadUser(req) {
  const id = req.session?.userId;
  if (!id) return null;
  const user = await prisma.user.findUnique({ where: { id }, include: USER_INCLUDE });
  if (!user || user.status !== 'ACTIVE') return null;
  if (Date.now() - user.lastSeenAt.getTime() > 60_000) {
    prisma.user.update({ where: { id }, data: { lastSeenAt: new Date() } }).catch(() => {});
  }
  return user;
}

export async function requireAuth(req, res, next) {
  try {
    const user = await loadUser(req);
    if (!user) return req.session.destroy(() => res.status(401).json({ error: 'Sign in required.' }));
    req.user = user;
    next();
  } catch (e) { next(e); }
}

export const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'Not allowed.' });
