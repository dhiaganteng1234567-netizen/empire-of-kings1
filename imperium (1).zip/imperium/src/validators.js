import { z } from 'zod';

export const registerSchema = z.object({
  username: z.string().trim().regex(/^[A-Za-z0-9_]{3,20}$/, 'Use 3–20 letters, numbers or underscores.'),
  email: z.string().trim().toLowerCase().email('Enter a valid email address.').max(254),
  password: z.string().min(10, 'Use at least 10 characters.').max(128),
  countryId: z.string().min(1, 'Choose a country.'),
});

export const loginSchema = z.object({
  identifier: z.string().trim().min(1, 'Enter your username or email.').max(254),
  password: z.string().min(1, 'Enter your password.').max(128),
});

export const profileSchema = z.object({
  displayName: z.string().trim().min(2, 'Use at least 2 characters.').max(30),
  bio: z.string().trim().max(280, 'Keep it under 280 characters.'),
  privacy: z.enum(['PUBLIC', 'PRIVATE']),
});
