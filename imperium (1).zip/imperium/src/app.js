import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ZodError } from 'zod';
import { config } from './config.js';
import { sessionMiddleware } from './session.js';
import { sameOriginGuard } from './middleware/security.js';
import authRoutes from './routes/auth.js';
import meRoutes from './routes/me.js';
import playerRoutes from './routes/players.js';
import worldRoutes from './routes/world.js';

const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

export function createApp() {
  const app = express();
  if (config.isProd) app.set('trust proxy', 1);

  app.use(helmet({
    contentSecurityPolicy: { useDefaults: true, directives: { 'upgrade-insecure-requests': config.isProd ? [] : null } },
  }));
  app.use(express.json({ limit: '20kb' }));
  app.use(express.static(publicDir));

  app.get('/healthz', (_req, res) => res.json({ ok: true }));

  app.use('/api', sessionMiddleware, sameOriginGuard);
  app.use('/api/auth', authRoutes);
  app.use('/api/me', meRoutes);
  app.use('/api/players', playerRoutes);
  app.use('/api/world', worldRoutes);
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof ZodError) {
      const fields = err.flatten().fieldErrors;
      const first = Object.values(fields).flat()[0] ?? 'Check the form and try again.';
      return res.status(400).json({ error: first, fields });
    }
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  });

  return app;
}
