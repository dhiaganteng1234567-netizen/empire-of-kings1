import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import pg from 'pg';
import { config } from './config.js';

const PgStore = connectPgSimple(session);
const pool = new pg.Pool({ connectionString: config.databaseUrl });

// Exported on its own so Stage 2 can share it with Socket.IO.
export const sessionMiddleware = session({
  store: new PgStore({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'imperium.sid',
  secret: config.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.isProd,
    maxAge: config.sessionMaxAgeMs,
  },
});
